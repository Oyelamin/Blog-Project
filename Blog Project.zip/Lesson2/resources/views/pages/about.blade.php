@extends('layouts.app')
@section('content')
<div class="about">

    <h1><img src="{{asset('img/heart.png')}}" class="heart">About The Project</h1>
    <p>ssdjsdjhdf dsfhdjsd sddhfsjdshjdshjdshdsd sjdfhsdjhsjdfs sdhjsfdjhsdjshdjshdjsdhsd dfuiwuiihdwf wwieuweiw wweuwieiweuwieuwewf
        eebfeufef efuefefhefuewhiwufhiwehiweiw wehjhejehrjehrejreeuwiefhwefwwittriwr wwewue
        iuwieuwieuwieuwe wwieuweerejhrejrhejrehjehejrhejrehrejrherjehrejehjrejrerehrerjererdfsdfsdiwwew
        wehjwhjhwjhewjhwjehwjewejjfjebfwefbwjejfjwfeebwfbfwhbejwje eewhffwbwhebjfwhf ewjhfjhfbrfhjbrf hjwejfhfjbwhefbeureeyre
    </p>
    <button class="btn btn-primary btn-lg">Read More</button>

</div>
@endsection