@extends('layouts.app')

@section('content')
<div class="text-section jumbotron">

    <h1>Lara-App</h1>
    <h3>This is my first laravel project</h3>
    <img src="{{asset('img/lara-img.png')}}">

</div>
@endsection