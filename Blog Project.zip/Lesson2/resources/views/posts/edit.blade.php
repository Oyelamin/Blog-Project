@extends('layouts.app')
@section('content')
<div class="post">
<h1>Edit</h1>
{!! Form::open(['action' => ['PostsController@update',$post_id->id], 'method' => 'POST','enctype'=>'multipart/form-data' ]) !!}
    <div class="form-group">
       <h4> {{Form::label('title','Title')}}</h4>
        {{Form::text('title',$post_id->title,['class'=>'form-control','placeholder'=>'Title'])}}
    </div>
    <div class="form-group">
        <h4> {{Form::label('body','Body')}}</h4>
        {{Form::textarea('body',$post_id->body,['id'=>'article-ckeditor','class'=>'form-control','placeholder'=>'Body Text'])}}
    </div>
    <div class="form-group">

            {{Form::file('cover_image')}}
    
        </div>
    {{Form::hidden('_method','PUT')}}
    {{Form::submit('Submit',['class'=>'btn btn-lg btn-primary', 'name' => 'submit'])}}
{!! Form::close() !!}
</div>
@endsection

