@extends('layouts.app')

@section('content')
<div class="posts jumbotron">

<div class="jumbotron">
    <a href="/posts"><img src="{{asset('img/left-arrow.png')}}" class="back"></a>

<div class="row">

    <div class="col-md-4 col-sm-4">
        <img src="/storage/cover_images/{{$post_id->cover_image}}" style="width:100%;border-radius:6px;"><br/><br/>
    </div>
    <div class="col-md-8 col-sm-8">
            <h1>{{$post_id->title}} <img src="{{asset('img/post-it.png')}}" class="tree-img"></h1>
<h5>{!!$post_id->body!!}</h5>
<hr/>
<small>Written on {{$post_id->created_at}} by <b>{{$post_id->user->name}}</b></small>
    </div>

</div>

</div>
<hr/>
@if(!Auth::guest())
    @if(Auth::user()->id == $post_id->user_id)
    <a href="/posts/{{$post_id->id}}/edit" class="btn btn-primary btn-lg">Edit</a>
    {!!Form::open(['action' =>['PostsController@destroy',$post_id->id],'method' => 'POST','class' => 'pull-right'])!!}
    {{Form::hidden('_method', 'DELETE')}}
    {{Form::submit('Delete',['class' => 'btn btn-lg btn-danger'])}}
    {!!Form::close()!!}
    @endif
@else
<small>Go ahead an Login or Register</small>
@endif
</div>
@endsection


@section('footer')