@extends('layouts.app')
@section('content')

<div class="posts">

    <h1>Posts <img src="{{asset('img/post-it.png')}}" class="tree-img"></h1>
    @if(count($posts) > 0)
    @foreach($posts as $post)
    <div class="jumbotron">
    <div class="row">
        <div class="col-md-4 col-sm-4">
            <img src="storage/cover_images/{{$post->cover_image}}" style="width:100%;">
        </div>
        <div class="col-md-8 col-sm-8">

            <h3><a href="posts/{{$post->id}}">{{$post->title}}</a><h3><hr/>
            <small>Written on {{$post->created_at}} by <b>{{$post->user->name}}</b></small>

        </div>
    </div>
    
    </div>
    @endforeach
    {{$posts->links()}}
    {{-- {{$post->links()}} --}}
    @else
    <div class="juumbotron alert alert-primary">
    <h3>No Posts Yet</h3>
    </div>
    @endif

</div>

@endsection