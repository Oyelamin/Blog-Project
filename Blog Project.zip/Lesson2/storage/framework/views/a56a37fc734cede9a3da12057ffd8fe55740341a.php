<?php $__env->startSection('content'); ?>
<div class="text-section jumbotron">

    <h1>Lara-App</h1>
    <h3>This is my first laravel project</h3>
    <img src="<?php echo e(asset('img/lara-img.png')); ?>">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>