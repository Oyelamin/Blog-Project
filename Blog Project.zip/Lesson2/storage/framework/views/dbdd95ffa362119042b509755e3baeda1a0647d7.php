<?php $__env->startSection('content'); ?>
<div class="posts jumbotron">

<div class="jumbotron">
    <a href="/posts"><img src="<?php echo e(asset('img/left-arrow.png')); ?>" class="back"></a>

<div class="row">

    <div class="col-md-4 col-sm-4">
        <img src="/storage/cover_images/<?php echo e($post_id->cover_image); ?>" style="width:100%;border-radius:6px;"><br/><br/>
    </div>
    <div class="col-md-8 col-sm-8">
            <h1><?php echo e($post_id->title); ?> <img src="<?php echo e(asset('img/post-it.png')); ?>" class="tree-img"></h1>
<h5><?php echo $post_id->body; ?></h5>
<hr/>
<small>Written on <?php echo e($post_id->created_at); ?> by <b><?php echo e($post_id->user->name); ?></b></small>
    </div>

</div>

</div>
<hr/>
<?php if(!Auth::guest()): ?>
    <?php if(Auth::user()->id == $post_id->user_id): ?>
    <a href="/posts/<?php echo e($post_id->id); ?>/edit" class="btn btn-primary btn-lg">Edit</a>
    <?php echo Form::open(['action' =>['PostsController@destroy',$post_id->id],'method' => 'POST','class' => 'pull-right']); ?>

    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

    <?php echo e(Form::submit('Delete',['class' => 'btn btn-lg btn-danger'])); ?>

    <?php echo Form::close(); ?>

    <?php endif; ?>
<?php else: ?>
<small>Go ahead an Login or Register</small>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>