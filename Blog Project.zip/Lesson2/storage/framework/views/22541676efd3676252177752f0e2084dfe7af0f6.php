<?php $__env->startSection('content'); ?>
<div class="about">

    <h1><img src="<?php echo e(asset('img/heart.png')); ?>" class="heart">About The Project</h1>
    <p>ssdjsdjhdf dsfhdjsd sddhfsjdshjdshjdshdsd sjdfhsdjhsjdfs sdhjsfdjhsdjshdjshdjsdhsd dfuiwuiihdwf wwieuweiw wweuwieiweuwieuwewf
        eebfeufef efuefefhefuewhiwufhiwehiweiw wehjhejehrjehrejreeuwiefhwefwwittriwr wwewue
        iuwieuwieuwieuwe wwieuweerejhrejrhejrehjehejrhejrehrejrherjehrejehjrejrerehrerjererdfsdfsdiwwew
        wehjwhjhwjhewjhwjehwjewejjfjebfwefbwjejfjwfeebwfbfwhbejwje eewhffwbwhebjfwhf ewjhfjhfbrfhjbrf hjwejfhfjbwhefbeureeyre
    </p>
    <button class="btn btn-primary btn-lg">Read More</button>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>