<nav class="nav">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <a class="navbar-brand" href="/">LARA-APP</a>
                </div>
                <div class="col-md-3">
                    <ul>
                        <li class="active"><a href="/">Home</a></li>
                        <li><a href="/about">About</a></li>
                        <li><a href="/services">Services</a></li>
                        <li><a href="/posts">Blog</a></li>
                    </ul>
                
    
                </div>
                <div class="col-md-3 create">
                        <ul>
                                <li class="active"><a href="/posts/create">Create Post</a></li>
    
                            </ul>
                </div>
            </div>
        </div>
    </nav>