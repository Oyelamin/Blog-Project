<?php if(count($errors) > 0): ?>
<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger"><h1><?php echo e($error); ?></h1></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
   <h1> <?php echo e(session('success')); ?></h1>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger">
    <h1>
<?php echo e(session('error')); ?></h1>
</div>
<?php endif; ?>

